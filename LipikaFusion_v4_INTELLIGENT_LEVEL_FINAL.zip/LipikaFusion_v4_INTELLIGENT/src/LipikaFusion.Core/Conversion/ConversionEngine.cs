
using System.Text;
using System.Text.RegularExpressions;

namespace LipikaFusion.Core;

public class ConversionEngine
{
    protected readonly MappingLoader _loader;
    public ConversionEngine(MappingLoader loader){ _loader = loader; }
    
    public virtual string ConvertToUnicode(string input, string profile)
    {
        var table = _loader.GetTable(profile);
        if(table==null || table.Count<5) table = _loader.GetMasterTable();
        return ApplyMapping(input, table);
    }

    protected string ApplyMapping(string input, Dictionary<string,string> table)
    {
        var sb=new StringBuilder();
        int i=0;
        while(i<input.Length){
            bool m=false;
            for(int l=Math.Min(4,input.Length-i); l>=1; l--){
                var key=input.Substring(i,l);
                if(table.TryGetValue(key,out var v)){ sb.Append(v); i+=l; m=true; break; }
            }
            if(!m){ sb.Append(input[i]); i++; }
        }
        return sb.ToString();
    }
}
