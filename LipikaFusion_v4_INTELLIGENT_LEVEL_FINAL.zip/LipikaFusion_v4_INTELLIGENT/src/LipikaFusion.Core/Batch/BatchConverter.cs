
namespace LipikaFusion.Core.Batch;

public class BatchResult
{
    public int Total{get;set;}
    public int Success{get;set;}
    public string OutputDir{get;set;}="";
    public string Log{get;set;}="";
}

public class BatchConverter
{
    private readonly IntelligentConverter _converter;
    public BatchConverter(IntelligentConverter converter){ _converter = converter; }

    public BatchResult ConvertFiles(string[] files, string from, string to)
    {
        var outputDir = Path.Combine(Path.GetTempPath(), "LipikaFusion_v4_Batch_"+DateTime.Now.ToString("yyyyMMdd_HHmmss"));
        Directory.CreateDirectory(outputDir);
        int success=0;
        var logLines = new List<string>();

        foreach(var file in files)
        {
            try
            {
                var text = File.ReadAllText(file);
                var result = _converter.ConvertIntelligent(text, from, to);
                var outFile = Path.Combine(outputDir, Path.GetFileNameWithoutExtension(file) + "_unicode.txt");
                File.WriteAllText(outFile, result.Output, System.Text.Encoding.UTF8);
                success++;
                logLines.Add($"{Path.GetFileName(file)}: {text.Length}->{result.Output.Length} chars - {result.Stats}");
            }
            catch(Exception ex)
            {
                logLines.Add($"{Path.GetFileName(file)}: FAILED - {ex.Message}");
            }
        }

        return new BatchResult{ Total=files.Length, Success=success, OutputDir=outputDir, Log=string.Join("\n", logLines) };
    }
}
