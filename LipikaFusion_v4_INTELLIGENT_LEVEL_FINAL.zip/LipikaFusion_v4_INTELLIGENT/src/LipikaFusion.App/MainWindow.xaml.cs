
using System.Windows;
using System.IO;
using Microsoft.Win32;
using LipikaFusion.Core;
using LipikaFusion.Core.Batch;

namespace LipikaFusion.App;

public partial class MainWindow : Window
{
    private readonly ConversionEngine _engine;
    private readonly IntelligentConverter _intelligent;
    private readonly BatchConverter _batch;

    public MainWindow()
    {
        InitializeComponent();
        var mapDir = Path.Combine(AppContext.BaseDirectory, "mappings", "marathi");
        if(!Directory.Exists(mapDir)) mapDir = "mappings/marathi";
        var loader = new MappingLoader(mapDir);
        _engine = new ConversionEngine(loader);
        _intelligent = new IntelligentConverter(loader);
        _batch = new BatchConverter(_intelligent);

        FromBox.Items.Add("Auto Detect (Legacy)");
        FromBox.Items.Add("4C Gandhi Bold");
        FromBox.Items.Add("4C Gaurav Regular");
        FromBox.Items.Add("ShreeLipi 0714");
        FromBox.Items.Add("ShreeLipi 0708");
        FromBox.Items.Add("Chanakya");
        FromBox.Items.Add("KrutiDev 010");
        FromBox.Items.Add("Unicode Devanagari");

        ToBox.Items.Add("Unicode Devanagari (NFC)");
        ToBox.Items.Add("4C Gandhi");
        ToBox.Items.Add("ShreeLipi 0714");
        ToBox.Items.Add("Chanakya");
        ToBox.Items.Add("KrutiDev 010");

        FromBox.SelectedIndex = 0;
        ToBox.SelectedIndex = 0;
    }

    private void Convert_Click(object sender, RoutedEventArgs e)
    {
        var from = FromBox.SelectedItem?.ToString() ?? "Auto";
        var to = ToBox.SelectedItem?.ToString() ?? "Unicode";
        var result = _intelligent.ConvertIntelligent(SourceBox.Text, from, to);
        OutputBox.Text = result.Output;
        IntelligenceLog.Text = result.Log;
        StatusText.Text = result.Stats;
    }

    private void Reverse_Click(object sender, RoutedEventArgs e)
    {
        var temp = FromBox.SelectedIndex;
        FromBox.SelectedIndex = ToBox.SelectedIndex;
        ToBox.SelectedIndex = temp;
        var tmpText = SourceBox.Text;
        SourceBox.Text = OutputBox.Text;
        OutputBox.Text = tmpText;
        Convert_Click(sender, e);
    }

    private void Batch_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog{ Multiselect=true, Filter="All supported|*.txt;*.docx;*.html;*.csv|Text|*.txt|All|*.*"};
        if(dlg.ShowDialog()==true)
        {
            var results = _batch.ConvertFiles(dlg.FileNames, FromBox.SelectedItem?.ToString() ?? "Auto", ToBox.SelectedItem?.ToString() ?? "Unicode");
            MessageBox.Show($"Batch Complete: {results.Success}/{results.Total} files converted\nSaved to: {results.OutputDir}\n\n{results.Log}", "Batch v4.0 Intelligent", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
