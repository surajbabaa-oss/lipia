
using LipikaFusion.Core;
var loader = new MappingLoader("mappings/marathi");
var intelligent = new IntelligentConverter(loader);
var from = args.Length>0 ? args[0] : "Auto";
var to = args.Length>1 ? args[1] : "Unicode";
Console.WriteLine($"LipikaFusion v4.0 Intelligent CLI - {from} -> {to}");
var input = Console.In.ReadToEnd();
var result = intelligent.ConvertIntelligent(input, from, to);
Console.WriteLine(result.Log);
Console.Write(result.Output);
