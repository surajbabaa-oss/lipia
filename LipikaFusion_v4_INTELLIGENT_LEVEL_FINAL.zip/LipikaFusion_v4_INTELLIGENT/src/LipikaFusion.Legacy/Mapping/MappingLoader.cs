
using System.Text.Json;
namespace LipikaFusion.Core;

public class MappingLoader
{
    private Dictionary<string, Dictionary<string,string>> _tables = new();
    private Dictionary<string, Dictionary<string,string>> _reverseTables = new();
    private Dictionary<string,string> _master;
    private Dictionary<string,string> _reverseMaster;

    public MappingLoader(string mapDir)
    {
        _master = new Dictionary<string,string>{ {"k","क"},
            {"K","ख"},
            {"g","ग"},
            {"G","घ"},
            {"c","च"},
            {"C","छ"},
            {"j","ज"},
            {"J","झ"},
            {"T","ट"},
            {"t","त"},
            {"Q","ठ"},
            {"q","थ"},
            {"D","ड"},
            {"d","द"},
            {"N","ण"},
            {"n","न"},
            {"p","प"},
            {"P","फ"},
            {"b","ब"},
            {"B","भ"},
            {"m","म"},
            {"y","य"},
            {"r","र"},
            {"l","ल"},
            {"L","ळ"},
            {"v","व"},
            {"s","स"},
            {"S","श"},
            {"h","ह"},
            {"a","ा"},
            {"A","आ"},
            {"e","े"},
            {"E","ै"},
            {"o","ो"},
            {"O","ौ"},
            {"i","ि"},
            {"I","ी"},
            {"u","ु"},
            {"U","ू"},
            {"f","ि"},
            {"w","ू"},
            {"`","ँ"},
            {"~","ं"},
            {"x","्"},
            {"X","्"},
            {";","त्र"},
            {":","ज्ञ"},
            {""","क्ष"},
            {"'","श्र"},
            {"<","क्र"},
            {">","प्र"},
            {"[","द्व"},
            {"]","द्ध"},
            {"{","ट्ट"},
            {"}","ट्ठ"},
            {"1","१"},
            {"2","२"},
            {"3","३"},
            {"4","४"},
            {"5","५"},
            {"6","६"},
            {"7","७"},
            {"8","८"},
            {"9","९"},
            {"0","०"},
            {"\","।"},
            {"|","॥"},
            {"#","रु"},
            {"$","रू"},
            {"%","कृ"},
            {"&","द्ध"},
            {"*","ष्ट"},
            {"+","ं"},
            {"=","ः"},
            {"@","ॐ"},
            {"!","क्त"},
            {"(","त्त"},
            {")","न्न"},
            {"?","ल्ल"} };
        _reverseMaster = new Dictionary<string,string>{ {"क","k"},
            {"ख","K"},
            {"ग","g"},
            {"घ","G"},
            {"च","c"},
            {"छ","C"},
            {"ज","j"},
            {"झ","J"},
            {"ट","T"},
            {"त","t"},
            {"ठ","Q"},
            {"थ","q"},
            {"ड","D"},
            {"द","d"},
            {"ण","N"},
            {"न","n"},
            {"प","p"},
            {"फ","P"},
            {"ब","b"},
            {"भ","B"},
            {"म","m"},
            {"य","y"},
            {"र","r"},
            {"ल","l"},
            {"ळ","L"},
            {"व","v"},
            {"स","s"},
            {"श","S"},
            {"ह","h"},
            {"ा","a"}, {"त्र",";"}, {"ज्ञ",":"}, {"क्ष","\""}, {"श्र","'"}, {"क्र","<"}, {"प्र",">"}, {"।","\\"}, {"॥","|"} };

        if(!Directory.Exists(mapDir)) mapDir = "mappings/marathi";
        if(Directory.Exists(mapDir))
        {
            foreach(var file in Directory.GetFiles(mapDir, "*.json"))
            {
                try{
                    var json=File.ReadAllText(file);
                    var dict=JsonSerializer.Deserialize<Dictionary<string,string>>(json);
                    if(dict!=null && dict.Count>5)
                    {
                        _tables[Path.GetFileNameWithoutExtension(file).ToLower()] = dict;
                        var rev = dict.GroupBy(kv=>kv.Value).ToDictionary(g=>g.Key, g=>g.First().Key);
                        _reverseTables[Path.GetFileNameWithoutExtension(file).ToLower()] = rev;
                    }
                }catch{}
            }
        }
    }

    public Dictionary<string,string> GetTable(string id)
    {
        if(string.IsNullOrEmpty(id)) return _master;
        var key=id.ToLower();
        foreach(var kv in _tables) if(key.Contains(kv.Key) || kv.Key.Contains(key)) return kv.Value;
        return _master;
    }

    public Dictionary<string,string> GetReverseTable(string id)
    {
        if(string.IsNullOrEmpty(id)) return _reverseMaster;
        var key=id.ToLower();
        foreach(var kv in _reverseTables) if(key.Contains(kv.Key) || kv.Key.Contains(key)) return kv.Value;
        return _reverseMaster;
    }

    public string DetectProfile(string text, string hint)
    {
        if(text.Any(c=>c>=0x0900 && c<=0x097F)) return "Unicode Devanagari - Auto";
        if(text.Contains(";") && text.Contains(":")) return "4C / ShreeLipi (Ligature ; : detected)";
        if(text.Contains("k") && text.Contains("f")) return "4C Gandhi/Gaurav (k+f pattern)";
        return "Auto Detect - Legacy";
    }

    public Dictionary<string,string> GetMasterTable()=>_master;
    public Dictionary<string,string> GetReverseMasterTable()=>_reverseMaster;
}
