#define MyAppName "Lipika Fusion PRO v4.0 INTELLIGENT"
#define MyAppVersion "4.0.0"
[Setup]
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={autopf}\LipikaFusionPROv4
DefaultGroupName=Lipika Fusion PRO v4
OutputDir=..\artifacts\installer
OutputBaseFilename=LipikaFusionPRO-Setup-v4-INTELLIGENT-ALL-FONTS
Compression=lzma2/ultra64
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64
WizardStyle=modern
[Files]
Source: "..\artifacts\publish\win-x64\*"; DestDir: "{app}"; Flags: recursesubdirs
Source: "..\mappings\*"; DestDir: "{app}\mappings"; Flags: recursesubdirs
[Icons]
Name: "{group}\Lipika Fusion PRO v4.0 INTELLIGENT"; Filename: "{app}\LipikaFusion.App.exe"
Name: "{autodesktop}\Lipika Fusion PRO v4.0"; Filename: "{app}\LipikaFusion.App.exe"
[Registry]
Root: HKCR; Subkey: "*\shell\LipikaFusionv4"; ValueType: string; ValueData: "Convert with LipikaFusion v4 INTELLIGENT"; Flags: uninsdeletekey
Root: HKCR; Subkey: "*\shell\LipikaFusionv4\command"; ValueType: string; ValueData: "\"{app}\LipikaFusion.App.exe\" \"%1\""
[Run]
Filename: "{app}\LipikaFusion.App.exe"; Description: "Launch v4.0 Intelligent"; Flags: nowait postinstall
